# csmGmmCorr 1.3.0

- Added a common estimated or fixed within-feature correlation matrix.
- Added support-specific magnitude mixtures and BIC structure selection.
- Added pleiotropy, same-direction replication, and paired-mediation targets.
- Added bounded-memory paired-state likelihood evaluation.
- Added optional monotone adjustment, incongruity, and extrapolation diagnostics.
- Added multi-start fitting and explicit reporting of nonconverged analyses.

