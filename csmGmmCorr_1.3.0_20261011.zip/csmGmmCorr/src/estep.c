#include <R.h>
#include <Rinternals.h>
#include <R_ext/Rdynload.h>
#include <math.h>

static SEXP csm_row_logsumexp(SEXP matrix_) {
    if (!isReal(matrix_) || !isMatrix(matrix_)) {
        error("expected a numeric matrix");
    }
    SEXP dim = getAttrib(matrix_, R_DimSymbol);
    int nr = INTEGER(dim)[0];
    int nc = INTEGER(dim)[1];
    const double *x = REAL(matrix_);
    SEXP answer = PROTECT(allocVector(REALSXP, nr));
    for (int i = 0; i < nr; ++i) {
        double peak = R_NegInf;
        for (int j = 0; j < nc; ++j) {
            double value = x[i + nr * j];
            if (value > peak) peak = value;
        }
        double total = 0.0;
        for (int j = 0; j < nc; ++j) {
            total += exp(x[i + nr * j] - peak);
        }
        REAL(answer)[i] = peak + log(total);
    }
    UNPROTECT(1);
    return answer;
}

static const R_CallMethodDef call_methods[] = {
    {"csm_row_logsumexp", (DL_FUNC) &csm_row_logsumexp, 1},
    {NULL, NULL, 0}
};

void R_init_csmGmmCorr(DllInfo *dll) {
    R_registerRoutines(dll, NULL, call_methods, NULL, NULL);
    R_useDynamicSymbols(dll, FALSE);
}

