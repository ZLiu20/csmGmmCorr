# csmGmmCorr

`csmGmmCorr` fits a correlated, conditionally symmetric multivariate Gaussian
mixture and uses the fitted posterior probabilities to test composite null
hypotheses. A common correlation matrix describes dependence among the test
statistics belonging to the same feature.

The package supports three scientific targets:

- **Pleiotropy:** more than `t` coordinates are nonzero.
- **Replication:** more than `t` coordinates are nonzero and have a common sign.
- **Paired mediation:** more than `t` coordinates are nonzero and at least one
  specified coordinate pair is jointly active.

## Minimal example

```r
library(csmGmmCorr)

spec <- csm_spec(K = 4, M = 1, b_mu = 8)
truth <- csm_params(
  spec,
  varpi = ifelse(spec$grp_b == 0, 0.8, 0.2 / (length(spec$grp_b) - 1)),
  mu = rep(2.5, 4),
  Sigma = 0.2 + 0.8 * diag(4)
)

set.seed(1)
training <- csm_simulate(2000, truth, spec)$z
fit <- csm_fit(training, spec, starts = c("null", "equal"))
result <- csm_test(fit, training, target = "pleiotropy", t = 1, q = 0.1)
print(result)
```

`csm_lfdr()` returns raw model-based local false discovery rates.
`csm_adjust()` optionally replaces them by an observed-set monotone majorant.
The latter enforces the specified ranking order but is a post-fit operation; it
is not a second fitted probability model.

## Model selection and compatibility

`csm_select()` compares a small collection of support-specific magnitude
structures by BIC. `as_sun_lists()` and the `pi`/list form accepted by
`csm_params()` provide a bridge to the list representation used by the
independent csmGmm implementation.

## Computational notes

Signed configurations are evaluated in positive/negative pairs. Data are
processed in bounded blocks and the E-step retains sufficient statistics rather
than a feature-by-state responsibility array. The complete state space defined
by `K`, `S`, and `M` is nevertheless included in the likelihood.

