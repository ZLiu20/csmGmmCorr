csm_control <- function(max_iter = 5000L, tol_loglik = NULL, tol_param = Inf,
                        accelerate = TRUE, warm_n = 0L, penalty = 30,
                        weight_penalty = 10, block_cells = 5e6,
                        sigma_steps = 50L, fix_sigma = FALSE, cores = 1L,
                        verbose = FALSE) {
  .scalar_number(max_iter, "max_iter", 1)
  if (!is.null(tol_loglik)) .scalar_number(tol_loglik, "tol_loglik", 0)
  .scalar_number(tol_param, "tol_param", 0)
  .scalar_number(warm_n, "warm_n", 0)
  .scalar_number(penalty, "penalty", 0)
  .scalar_number(weight_penalty, "weight_penalty", 0)
  .scalar_number(block_cells, "block_cells", 100)
  .scalar_number(sigma_steps, "sigma_steps", 1)
  .scalar_number(cores, "cores", 1)
  if (!(is.logical(fix_sigma) && length(fix_sigma) == 1L) && !is.matrix(fix_sigma)) {
    stop("'fix_sigma' must be TRUE, FALSE, or a correlation matrix.", call. = FALSE)
  }
  list(max_iter = as.integer(max_iter), tol_loglik = tol_loglik, tol_param = tol_param,
       accelerate = isTRUE(accelerate), warm_n = as.integer(warm_n),
       penalty = as.numeric(penalty), weight_penalty = as.numeric(weight_penalty),
       block_cells = as.numeric(block_cells), sigma_steps = as.integer(sigma_steps),
       fix_sigma = fix_sigma, cores = as.integer(cores), verbose = isTRUE(verbose))
}

.fixed_sigma <- function(control, K) {
  x <- control$fix_sigma
  if (is.matrix(x)) {
    if (!identical(dim(x), c(K, K)) || any(!is.finite(x)) ||
        max(abs(x - t(x))) > 1e-10 || max(abs(diag(x) - 1)) > 1e-10 ||
        min(eigen(x, symmetric = TRUE, only.values = TRUE)$values) <= 0) {
      stop("'fix_sigma' is not a positive-definite K by K correlation matrix.", call. = FALSE)
    }
    return((x + t(x)) / 2)
  }
  if (isTRUE(x)) diag(K) else NULL
}

.base_signal <- function(X, spec) {
  apply(abs(X), 2L, function(v) {
    upper <- v[v >= stats::quantile(v, 0.75, names = FALSE)]
    pmin(spec$b_mu, pmax(spec$a_mu, if (length(upper)) mean(upper) else 2.5))
  })
}

.initial_mu <- function(base, spec) {
  G <- length(spec$grp_b)
  ans <- matrix(0, G, spec$K)
  for (g in which(spec$grp_b != 0L)) {
    m_count <- spec$M[spec$grp_b[g] + 1L]
    fraction <- if (spec$grp_b[g] == 2^spec$K - 1L) {
      1 + 0.5 * (spec$grp_m[g] - 1L) / max(1L, m_count - 1L)
    } else {
      0.5 + 0.5 * spec$grp_m[g] / m_count
    }
    ans[g, ] <- spec$grp_A[g, ] * base * fraction
  }
  .project_mu(ans, spec)
}

.start_parameters <- function(X, spec, type = c("null", "equal", "shared")) {
  type <- match.arg(type)
  G <- length(spec$grp_b)
  if (type == "equal") {
    varpi <- rep(1 / G, G)
  } else {
    varpi <- ifelse(spec$grp_b == 0L, 0.5, 0.5 / max(1L, G - 1L))
  }
  base <- .base_signal(X, spec)
  mu <- .initial_mu(base, spec)
  if (type == "shared") {
    for (k in seq_len(spec$K)) mu[spec$grp_A[, k] == 1L, k] <- base[k]
    mu <- .project_mu(mu, spec)
  }
  list(varpi = varpi, mu = mu, Sigma = diag(spec$K))
}

.random_parameters <- function(X, spec) {
  p <- .start_parameters(X, spec, "null")
  p$varpi <- p$varpi * exp(stats::rnorm(length(p$varpi), 0, 0.5))
  p$varpi <- p$varpi / sum(p$varpi)
  p$mu <- .project_mu(p$mu * exp(matrix(stats::rnorm(length(p$mu), 0, 0.25), nrow(p$mu))), spec)
  rho <- stats::runif(1L, 0, 0.3)
  p$Sigma <- .project_correlation((1 - rho) * diag(spec$K) + rho, spec$kappa)
  p
}

.objective <- function(es, params, spec, control, N) {
  es$F - control$penalty * .magnitude_penalty(params$mu, spec) / N -
    control$weight_penalty * .weight_penalty(params$varpi, spec) / N
}

.parameter_distance <- function(a, b) {
  max(abs(c(a$varpi - b$varpi, a$mu - b$mu, a$Sigma - b$Sigma)))
}

.blend_parameters <- function(old, proposed, fraction, spec) {
  lw_old <- log(pmax(old$varpi, .Machine$double.xmin))
  lw_new <- log(pmax(proposed$varpi, .Machine$double.xmin))
  w <- exp((1 - fraction) * lw_old + fraction * lw_new)
  w <- w / sum(w)
  structure(list(
    varpi = w,
    mu = .project_mu((1 - fraction) * old$mu + fraction * proposed$mu, spec),
    Sigma = .project_correlation((1 - fraction) * old$Sigma + fraction * proposed$Sigma, spec$kappa)
  ), class = "csm_params")
}

.square_candidate <- function(p0, p1, p2, spec) {
  positive <- p0$varpi > 0 & p1$varpi > 0 & p2$varpi > 0
  transform <- function(p) c(log(p$varpi[positive]), p$mu, p$Sigma)
  x0 <- transform(p0)
  r <- transform(p1) - x0
  v <- transform(p2) - transform(p1) - r
  denom <- sum(v^2)
  if (!is.finite(denom) || denom <= 0) return(NULL)
  alpha <- -sqrt(sum(r^2) / denom)
  alpha <- max(-100, min(-1, alpha))
  a <- (1 + alpha)^2
  b <- -2 * alpha * (1 + alpha)
  c <- alpha^2
  logw <- rep(-Inf, length(p0$varpi))
  logw[positive] <- a * log(p0$varpi[positive]) + b * log(p1$varpi[positive]) +
    c * log(p2$varpi[positive])
  logw[positive] <- logw[positive] - max(logw[positive])
  w <- exp(logw)
  w <- w / sum(w)
  structure(list(
    varpi = w,
    mu = .project_mu(a * p0$mu + b * p1$mu + c * p2$mu, spec),
    Sigma = .project_correlation(a * p0$Sigma + b * p1$Sigma + c * p2$Sigma, spec$kappa)
  ), class = "csm_params")
}

.fit_once <- function(X, spec, initial, control) {
  N <- nrow(X)
  tol_ll <- if (is.null(control$tol_loglik)) 0.01 / N else control$tol_loglik
  params <- structure(initial, class = "csm_params")
  fixed <- .fixed_sigma(control, spec$K)
  if (!is.null(fixed)) params$Sigma <- fixed
  XtX <- crossprod(X) / N
  current <- .estep(X, spec, params, stats = TRUE, block_cells = control$block_cells, cores = control$cores)
  objective <- .objective(current, params, spec, control, N)
  trace <- objective
  status <- "max_iter"
  iteration <- 0L
  while (iteration < control$max_iter) {
    proposed1 <- .ecm_update(X, current, params, spec, control, XtX)
    evaluated1 <- .estep(X, spec, proposed1, stats = TRUE,
                         block_cells = control$block_cells, cores = control$cores)
    proposed <- proposed1
    evaluated <- evaluated1
    used_steps <- 1L
    if (isTRUE(control$accelerate) && iteration + 1L < control$max_iter) {
      proposed2 <- .ecm_update(X, evaluated1, proposed1, spec, control, XtX)
      evaluated2 <- .estep(X, spec, proposed2, stats = TRUE,
                           block_cells = control$block_cells, cores = control$cores)
      proposed <- proposed2
      evaluated <- evaluated2
      used_steps <- 2L
      sq <- .square_candidate(params, proposed1, proposed2, spec)
      if (!is.null(sq)) {
        sq_eval <- .estep(X, spec, sq, stats = TRUE,
                          block_cells = control$block_cells, cores = control$cores)
        sq_map <- .ecm_update(X, sq_eval, sq, spec, control, XtX)
        sq_map_eval <- .estep(X, spec, sq_map, stats = TRUE,
                              block_cells = control$block_cells, cores = control$cores)
        if (.objective(sq_map_eval, sq_map, spec, control, N) >=
            .objective(evaluated2, proposed2, spec, control, N)) {
          proposed <- sq_map
          evaluated <- sq_map_eval
          used_steps <- 3L
        }
      }
    }
    new_objective <- .objective(evaluated, proposed, spec, control, N)
    if (!is.finite(new_objective)) {
      status <- "nonfinite"
      break
    }
    if (new_objective + 1e-10 * (1 + abs(objective)) < objective) {
      accepted <- FALSE
      for (fraction in 2^-(1:20)) {
        trial <- .blend_parameters(params, proposed, fraction, spec)
        trial_es <- .estep(X, spec, trial, stats = TRUE,
                           block_cells = control$block_cells, cores = control$cores)
        trial_objective <- .objective(trial_es, trial, spec, control, N)
        if (trial_objective >= objective - 1e-10 * (1 + abs(objective))) {
          proposed <- trial
          evaluated <- trial_es
          new_objective <- trial_objective
          accepted <- TRUE
          break
        }
      }
      if (!accepted) {
        status <- "stalled"
        break
      }
    }
    delta_ll <- evaluated$F - current$F
    delta_param <- .parameter_distance(proposed, params)
    params <- proposed
    current <- evaluated
    objective <- new_objective
    trace <- c(trace, objective)
    iteration <- iteration + used_steps
    if (control$verbose && (iteration == 1L || iteration %% 25L == 0L)) {
      message(sprintf("ECM iteration %d: average log-likelihood %.8f", iteration, current$F))
    }
    numerical_slack <- 1e-10 * (1 + abs(current$F))
    if (delta_ll >= -numerical_slack && delta_ll <= tol_ll && delta_param <= control$tol_param) {
      status <- "converged"
      break
    }
  }
  list(params = params, loglik = current$F, objective = objective,
       iterations = iteration, status = status, trace = trace)
}

.warm_indices <- function(N, m) {
  if (m <= 0L || m >= N) return(seq_len(N))
  key <- (seq_len(N) * 0.6180339887498949) %% 1
  sort(order(key)[seq_len(m)])
}

.fit_with_warm_start <- function(X, spec, initial, control) {
  N <- nrow(X)
  if (control$warm_n <= 0L || N < 3L * control$warm_n) return(.fit_once(X, spec, initial, control))
  warm_control <- control
  warm_control$warm_n <- 0L
  preliminary <- .fit_once(X[.warm_indices(N, control$warm_n), , drop = FALSE], spec, initial, warm_control)
  full <- .fit_once(X, spec, unclass(preliminary$params), warm_control)
  full$warm_iterations <- preliminary$iterations
  full
}

csm_fit <- function(X, spec, starts = c("null", "equal", "shared"), n_random = 0L,
                    init = NULL, control = csm_control(), seed = NULL) {
  if (!inherits(spec, "csm_spec")) stop("'spec' must come from csm_spec().", call. = FALSE)
  X <- .validate_z(X, spec$K, "X")
  if (nrow(X) < 2L) stop("'X' must have at least two rows.", call. = FALSE)
  if (is.infinite(spec$b_mu)) spec$b_mu <- max(spec$a_mu + 1, ceiling(max(abs(X)) + 1))
  starts <- unique(starts)
  if (!all(starts %in% c("null", "equal", "shared"))) stop("Unknown starting-value label.", call. = FALSE)
  .scalar_number(n_random, "n_random", 0)
  if (!is.null(seed)) set.seed(seed)
  initial <- list()
  for (s in starts) initial[[s]] <- .start_parameters(X, spec, s)
  for (i in seq_len(as.integer(n_random))) initial[[paste0("random", i)]] <- .random_parameters(X, spec)
  if (!is.null(init)) {
    if (inherits(init, "csm_params")) init <- list(init)
    if (!is.list(init)) stop("'init' must be a csm_params object or list of them.", call. = FALSE)
    for (i in seq_along(init)) {
      p <- init[[i]]
      if (length(.parameter_issues(p, spec))) stop(sprintf("init[%d] is infeasible.", i), call. = FALSE)
      initial[[paste0("init", i)]] <- unclass(p)
    }
  }
  if (!length(initial)) stop("No starting values were requested.", call. = FALSE)
  fixed <- .fixed_sigma(control, spec$K)
  if (!is.null(fixed)) for (i in seq_along(initial)) initial[[i]]$Sigma <- fixed
  runs <- lapply(initial, function(p) {
    tryCatch(.fit_with_warm_start(X, spec, p, control),
             error = function(e) list(status = "error", message = conditionMessage(e),
                                      loglik = NA_real_, objective = NA_real_, iterations = 0L))
  })
  summary <- data.frame(
    start = names(runs),
    status = vapply(runs, `[[`, character(1), "status"),
    iterations = vapply(runs, function(r) as.integer(r$iterations %||% 0L), integer(1)),
    warm_iterations = vapply(runs, function(r) as.integer(r$warm_iterations %||% NA_integer_), integer(1)),
    loglik = vapply(runs, function(r) r$loglik %||% NA_real_, numeric(1)),
    objective = vapply(runs, function(r) r$objective %||% NA_real_, numeric(1)),
    stringsAsFactors = FALSE
  )
  ok <- which(summary$status == "converged" & is.finite(summary$objective))
  converged <- length(ok) > 0L
  finite <- which(is.finite(summary$objective))
  pick <- if (converged) ok[which.max(summary$objective[ok])] else if (length(finite)) finite[which.max(summary$objective[finite])] else NA_integer_
  structure(list(
    params = if (is.na(pick)) NULL else runs[[pick]]$params,
    loglik = if (is.na(pick)) NA_real_ else runs[[pick]]$loglik,
    objective = if (is.na(pick)) NA_real_ else runs[[pick]]$objective,
    selected = if (is.na(pick)) NA_character_ else names(runs)[pick],
    converged = converged,
    runs = summary,
    traces = lapply(runs, function(r) r$trace),
    spec = spec, n = nrow(X), control = control
  ), class = "csm_fit")
}

`%||%` <- function(x, y) if (is.null(x)) y else x

print.csm_fit <- function(x, ...) {
  cat("Correlated csmGmm fit\n")
  cat(sprintf("  K = %d, N = %d, largest support size = %d\n", x$spec$K, x$n, x$spec$S))
  if (x$converged) cat(sprintf("  selected start: %s, average log-likelihood %.6f\n", x$selected, x$loglik))
  else cat("  no starting value converged; inferential wrappers make no discoveries\n")
  print(x$runs, row.names = FALSE)
  invisible(x)
}

logLik.csm_fit <- function(object, ...) {
  G <- length(object$spec$grp_b)
  n_w <- G - 1L
  n_mu <- sum(object$spec$grp_A)
  n_sigma <- if (is.null(.fixed_sigma(object$control, object$spec$K))) object$spec$K * (object$spec$K - 1L) / 2L else 0L
  structure(object$loglik * object$n, df = n_w + n_mu + n_sigma,
            nobs = object$n, class = "logLik")
}
