.validate_z <- function(z, K, label = "z") {
  if (is.data.frame(z)) z <- as.matrix(z)
  if (is.numeric(z) && is.null(dim(z)) && length(z) == K) z <- matrix(z, 1L)
  if (!is.matrix(z) || !is.numeric(z) || ncol(z) != K || any(!is.finite(z))) {
    stop(sprintf("'%s' must be a finite numeric matrix with %d columns.", label, K), call. = FALSE)
  }
  storage.mode(z) <- "double"
  z
}

.pair_model <- function(spec, params) {
  pr <- spec$pair
  active <- params$varpi[pr$grp] > 0
  H <- pr$H[active, , drop = FALSE]
  grp <- pr$grp[active]
  size <- pr$size[active]
  self <- pr$self[active]
  mean <- H * params$mu[grp, , drop = FALSE]
  U <- chol(params$Sigma)
  precision <- chol2inv(U)
  mean_precision <- mean %*% precision
  list(
    H = H, grp = grp, size = size, self = self,
    mean = mean, precision = precision,
    linear_mean = mean_precision,
    log_constant = log(params$varpi[grp]) - size * log(2) -
      0.5 * rowSums(mean_precision * mean),
    gaussian_constant = -0.5 * (spec$K * log(2 * pi) + 2 * sum(log(diag(U))))
  )
}

.row_logsumexp <- function(a, b = NULL) {
  if (is.null(b)) {
    m <- apply(a, 1L, max)
    return(m + log(rowSums(exp(a - m))))
  }
  m <- pmax(apply(a, 1L, max), apply(b, 1L, max))
  m + log(rowSums(exp(a - m)) + rowSums(exp(b - m)))
}

.chunk_rows <- function(n_pairs, block_cells) {
  max(1L, as.integer(floor(block_cells / max(1L, n_pairs))))
}

.pair_block <- function(z, model) {
  q <- z %*% model$precision
  base <- -0.5 * rowSums(q * z) + model$gaussian_constant
  lin <- z %*% t(model$linear_mean)
  plus <- sweep(lin, 2L, model$log_constant, "+")
  minus <- sweep(-lin, 2L, model$log_constant, "+")
  if (any(model$self)) minus[, model$self] <- -Inf
  den <- .row_logsumexp(plus, minus)
  rp <- exp(plus - den)
  rm <- exp(minus - den)
  list(total = rp + rm, difference = rp - rm, log_density = den + base)
}

.estep <- function(X, spec, params, stats = TRUE, block_cells = 5e6, cores = 1L) {
  X <- .validate_z(X, spec$K, "X")
  model <- .pair_model(spec, params)
  P <- nrow(model$H)
  N <- nrow(X)
  step <- .chunk_rows(P, block_cells)
  loglik <- 0
  if (stats) {
    T <- numeric(P)
    B <- matrix(0, P, spec$K)
  }
  for (first in seq.int(1L, N, by = step)) {
    take <- first:min(N, first + step - 1L)
    cur <- .pair_block(X[take, , drop = FALSE], model)
    loglik <- loglik + sum(cur$log_density)
    if (stats) {
      T <- T + colSums(cur$total)
      B <- B + crossprod(cur$difference, X[take, , drop = FALSE])
    }
  }
  out <- list(F = loglik / N, precision = model$precision, model = model)
  if (stats) {
    out$T <- T / N
    out$B <- B / N
  }
  out
}

csm_null_components <- function(H, target = c("pleiotropy", "replication", "mediation"),
                                t = 1L, pairs = NULL) {
  target <- match.arg(target)
  H <- as.matrix(H)
  K <- ncol(H)
  if (!is.numeric(t) || length(t) != 1L || is.na(t) || t != round(t) || t < 1L || t >= K) {
    stop("'t' must be an integer with 1 <= t < K.", call. = FALSE)
  }
  active <- rowSums(H != 0)
  if (target == "pleiotropy") return(active <= t)
  if (target == "replication") {
    same_direction <- abs(rowSums(H)) == active
    return(!(active > t & same_direction))
  }
  pairs <- .validate_pairs(pairs, K)
  complete <- rowSums((H[, pairs[, 1L], drop = FALSE] != 0) &
                      (H[, pairs[, 2L], drop = FALSE] != 0))
  !(active > t & complete > 0L)
}

.validate_pairs <- function(pairs, K) {
  if (is.null(pairs)) {
    if (K %% 2L) stop("Mediation with odd K requires an explicit 'pairs' matrix.", call. = FALSE)
    return(matrix(seq_len(K), ncol = 2L, byrow = TRUE))
  }
  pairs <- as.matrix(pairs)
  if (ncol(pairs) != 2L || any(!pairs %in% seq_len(K)) || anyDuplicated(as.vector(pairs))) {
    stop("'pairs' must have two columns of distinct coordinate indices.", call. = FALSE)
  }
  storage.mode(pairs) <- "integer"
  pairs
}

.lfdr_stream <- function(z, spec, params, null_pair, block_cells, cores) {
  model <- .pair_model(spec, params)
  null_pair <- null_pair[params$varpi[spec$pair$grp] > 0]
  if (!any(null_pair)) return(numeric(nrow(z)))
  if (all(null_pair)) return(rep(1, nrow(z)))
  P <- nrow(model$H)
  ans <- numeric(nrow(z))
  step <- .chunk_rows(P, block_cells)
  for (first in seq.int(1L, nrow(z), by = step)) {
    take <- first:min(nrow(z), first + step - 1L)
    zc <- z[take, , drop = FALSE]
    q <- zc %*% model$precision
    base <- -0.5 * rowSums(q * zc) + model$gaussian_constant
    lin <- zc %*% t(model$linear_mean)
    lp <- sweep(lin, 2L, model$log_constant, "+")
    lm <- sweep(-lin, 2L, model$log_constant, "+")
    if (any(model$self)) lm[, model$self] <- -Inf
    all_log <- .row_logsumexp(lp, lm)
    null_log <- .row_logsumexp(lp[, null_pair, drop = FALSE], lm[, null_pair, drop = FALSE])
    ans[take] <- exp(null_log - all_log)
  }
  pmin(1, pmax(0, ans))
}

csm_lfdr <- function(object, z, target = c("pleiotropy", "replication", "mediation"),
                     t = 1L, pairs = NULL, spec = NULL, block_cells = 5e6,
                     cores = 1L) {
  target <- match.arg(target)
  if (inherits(object, "csm_fit")) {
    spec <- object$spec
    params <- object$params
  } else {
    params <- object
    if (!inherits(spec, "csm_spec")) stop("'spec' is required with a parameter object.", call. = FALSE)
  }
  z <- .validate_z(z, spec$K)
  null_pair <- csm_null_components(spec$pair$H, target, t, pairs)
  .lfdr_stream(z, spec, params, null_pair, block_cells, cores)
}

