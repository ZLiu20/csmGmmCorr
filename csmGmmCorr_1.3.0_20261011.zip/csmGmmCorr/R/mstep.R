.weight_update <- function(pair_mass, spec, pseudo = 0) {
  group_mass <- rowsum(pair_mass, spec$pair$grp, reorder = TRUE)[, 1L]
  group_mass <- pmax(group_mass, 0)
  if (pseudo > 0) {
    for (s in unique(spec$grp_size)) {
      g <- which(spec$grp_size == s)
      total <- sum(group_mass[g])
      group_mass[g] <- (group_mass[g] + pseudo) / (total + length(g) * pseudo) * total
    }
  }
  if (sum(group_mass) <= 0) stop("The E-step assigned no mixture mass.", call. = FALSE)
  group_mass / sum(group_mass)
}

.box_solve <- function(Q, c, lower, upper, initial, maxit = 4000L, tol = 1e-10) {
  Q <- (Q + t(Q)) / 2
  ridge <- max(1e-10, -min(eigen(Q, symmetric = TRUE, only.values = TRUE)$values) + 1e-10)
  Q <- Q + diag(ridge, nrow(Q))
  raw <- tryCatch(solve(Q, c), error = function(e) NULL)
  if (!is.null(raw) && all(raw >= lower) && all(raw <= upper)) return(as.numeric(raw))
  x <- pmin(upper, pmax(lower, initial))
  d <- diag(Q)
  d[d <= 0] <- 1
  for (it in seq_len(maxit)) {
    old <- x
    for (k in seq_along(x)) {
      x[k] <- pmin(upper[k], pmax(lower[k], x[k] + (c[k] - sum(Q[k, ] * x)) / d[k]))
    }
    if (max(abs(x - old)) <= tol * (1 + max(abs(x)))) break
  }
  x
}

.mu_update <- function(es, spec, current, penalty = 0) {
  G <- length(spec$grp_b)
  K <- spec$K
  H <- es$model$H
  grp <- es$model$grp
  Omega <- es$precision
  candidate <- current
  size_mean <- matrix(0, spec$S, K)
  if (penalty > 0) {
    for (s in seq_len(spec$S)) for (k in seq_len(K)) {
      g <- which(spec$grp_size == s & spec$grp_A[, k] == 1L)
      if (length(g)) size_mean[s, k] <- mean(current[g, k])
    }
  }
  for (g in which(spec$grp_b != 0L)) {
    pg <- which(grp == g)
    active <- which(spec$grp_A[g, ] == 1L)
    Q <- matrix(0, length(active), length(active))
    rhs <- numeric(length(active))
    for (p in pg) {
      h <- H[p, active]
      Q <- Q + es$T[p] * (outer(h, h) * Omega[active, active, drop = FALSE])
      rhs <- rhs + h * as.vector(Omega[active, , drop = FALSE] %*% es$B[p, ])
    }
    if (penalty > 0) {
      Q <- Q + diag(penalty, length(active))
      rhs <- rhs + penalty * size_mean[spec$grp_size[g], active]
    }
    candidate[g, active] <- .box_solve(
      Q, rhs, rep(spec$a_mu, length(active)), rep(spec$b_mu, length(active)), current[g, active]
    )
  }
  .project_mu(candidate, spec)
}

.scatter_update <- function(XtX, es, mu, spec) {
  S <- XtX
  for (p in seq_len(nrow(es$model$H))) {
    g <- es$model$grp[p]
    m <- es$model$H[p, ] * mu[g, ]
    b <- es$B[p, ]
    S <- S - tcrossprod(b, m) - tcrossprod(m, b) + es$T[p] * tcrossprod(m)
  }
  (S + t(S)) / 2
}

.sigma_objective <- function(R, S) {
  U <- tryCatch(chol(R), error = function(e) NULL)
  if (is.null(U)) return(Inf)
  2 * sum(log(diag(U))) + sum(chol2inv(U) * S)
}

.sigma_update <- function(S, old, kappa, maxit = 50L) {
  proposal <- .project_correlation(S, kappa)
  if (.sigma_objective(proposal, S) <= .sigma_objective(old, S)) proposal else old
}

.weight_penalty <- function(varpi, spec) {
  out <- 0
  for (s in unique(spec$grp_size)) {
    g <- which(spec$grp_size == s)
    total <- sum(varpi[g])
    share <- if (total > 0) varpi[g] / total else rep(1 / length(g), length(g))
    out <- out - sum(log(pmax(share, .Machine$double.xmin)))
  }
  out
}

.magnitude_penalty <- function(mu, spec) {
  total <- 0
  for (s in seq_len(spec$S)) for (k in seq_len(spec$K)) {
    g <- which(spec$grp_size == s & spec$grp_A[, k] == 1L)
    if (length(g) > 1L) total <- total + sum((mu[g, k] - mean(mu[g, k]))^2) / 2
  }
  total
}

.ecm_update <- function(X, es, params, spec, control, XtX) {
  next_params <- params
  next_params$varpi <- .weight_update(es$T, spec, control$weight_penalty / nrow(X))
  next_params$mu <- .mu_update(es, spec, params$mu, control$penalty / nrow(X))
  fixed <- .fixed_sigma(control, spec$K)
  if (is.null(fixed)) {
    S <- .scatter_update(XtX, es, next_params$mu, spec)
    next_params$Sigma <- .sigma_update(S, params$Sigma, spec$kappa, control$sigma_steps)
  } else {
    next_params$Sigma <- fixed
  }
  structure(next_params, class = "csm_params")
}
