csm_structure <- function(K, single = 1L, multiple = 1L) {
  .scalar_number(K, "K", 2, 20)
  .scalar_number(single, "single", 1)
  .scalar_number(multiple, "multiple", 1)
  s <- .support_matrix(as.integer(K))$size
  as.integer(ifelse(s == 0L, 1L, ifelse(s == 1L, single, multiple)))
}

.candidate_structures <- function() {
  list(A = c(single = 1L, multiple = 1L),
       B = c(single = 2L, multiple = 1L),
       C = c(single = 2L, multiple = 2L))
}

csm_select <- function(X, K, structures = .candidate_structures(), bic_tol = 0,
                       starts = c("null", "shared"), control = csm_control(),
                       S = K, a_mu = 0.5, b_mu = NULL, kappa = 0.05,
                       seed = NULL) {
  if (!is.list(structures) || !length(structures) || is.null(names(structures))) {
    stop("'structures' must be a named list.", call. = FALSE)
  }
  .scalar_number(bic_tol, "bic_tol", 0)
  fits <- vector("list", length(structures))
  tab <- data.frame(structure = names(structures), single = NA_integer_, multiple = NA_integer_,
                    df = NA_real_, loglik = NA_real_, BIC = NA_real_, converged = FALSE,
                    minutes = NA_real_, stringsAsFactors = FALSE)
  for (i in seq_along(structures)) {
    st <- structures[[i]]
    M <- csm_structure(K, st[["single"]], st[["multiple"]])
    sp <- csm_spec(K, M, S, a_mu, b_mu, kappa)
    tm <- system.time(fits[[i]] <- csm_fit(X, sp, starts = starts, control = control, seed = seed))["elapsed"]
    tab$single[i] <- st[["single"]]
    tab$multiple[i] <- st[["multiple"]]
    tab$converged[i] <- fits[[i]]$converged
    tab$minutes[i] <- as.numeric(tm) / 60
    if (fits[[i]]$converged) {
      ll <- logLik(fits[[i]])
      tab$df[i] <- attr(ll, "df")
      tab$loglik[i] <- as.numeric(ll)
      tab$BIC[i] <- -2 * tab$loglik[i] + tab$df[i] * log(nrow(X))
    }
  }
  ok <- which(tab$converged & is.finite(tab$BIC))
  if (!length(ok)) stop("No candidate structure converged.", call. = FALSE)
  best <- ok[which.min(tab$BIC[ok])]
  near <- ok[tab$BIC[ok] <= tab$BIC[best] + bic_tol]
  pick <- near[which.max(tab$df[near])]
  tab$delta_BIC <- tab$BIC - tab$BIC[best]
  tab$chosen <- seq_len(nrow(tab)) == pick
  ans <- fits[[pick]]
  ans$selection <- tab
  ans$all_fits <- fits
  ans
}
