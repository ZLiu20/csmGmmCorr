.order_representation <- function(z, target, t) {
  if (target == "replication") {
    k <- as.integer(t) + 1L
    kth <- function(a) apply(a, 1L, function(v) sort(v, decreasing = TRUE)[k])
    positive <- kth(z) >= kth(-z)
    return(list(group = ifelse(positive, "+", "-"),
                w = ifelse(positive, 1, -1) * z))
  }
  zero_pattern <- apply(z == 0, 1L, paste0, collapse = "")
  sign_pattern <- apply(z > 0, 1L, paste0, collapse = "")
  list(group = paste(zero_pattern, sign_pattern, sep = ":"), w = abs(z))
}

.dominance_majorant <- function(w, score, group, indices = seq_along(score)) {
  result <- score
  for (g in unique(group[indices])) {
    candidates <- indices[group[indices] == g]
    members <- which(group == g)
    for (i in candidates) {
      dominates <- rowSums(w[members, , drop = FALSE] >=
                           matrix(w[i, ], length(members), ncol(w), byrow = TRUE)) == ncol(w)
      if (any(dominates)) result[i] <- max(score[members[dominates]])
    }
  }
  result
}

csm_adjust <- function(z, lfdr, target = c("pleiotropy", "replication", "mediation"),
                       t = 1L, q = 0.1, all = FALSE) {
  target <- match.arg(target)
  z <- as.matrix(z)
  if (!is.numeric(z) || nrow(z) != length(lfdr) || any(!is.finite(z))) {
    stop("'z' must be a finite numeric matrix with one row per lfdr value.", call. = FALSE)
  }
  if (!is.numeric(t) || length(t) != 1L || t < 1L || t >= ncol(z)) stop("'t' must satisfy 1 <= t < K.", call. = FALSE)
  rep <- .order_representation(z, target, as.integer(t))
  J <- nrow(z)
  if (all) {
    adjusted <- .dominance_majorant(rep$w, lfdr, rep$group)
    decision <- csm_stepup(adjusted, q)
    return(c(list(adjusted = adjusted, exact = rep(TRUE, J)), decision))
  }
  ord <- order(lfdr, seq_len(J))
  n_exact <- min(J, max(100L, 2L * csm_stepup(lfdr, q)$n_rejected))
  repeat {
    chosen <- ord[seq_len(n_exact)]
    adjusted_part <- .dominance_majorant(rep$w, lfdr, rep$group, chosen)
    candidate <- lfdr
    candidate[chosen] <- adjusted_part[chosen]
    decision <- csm_stepup(candidate, q)
    exact <- rep(FALSE, J)
    exact[chosen] <- TRUE
    safe <- decision$n_rejected == 0L ||
      (all(exact[decision$rejected]) &&
       max(candidate[decision$rejected]) <= min(lfdr[!exact], Inf))
    if (n_exact == J || safe) break
    n_exact <- min(J, 2L * n_exact)
  }
  adjusted <- rep(NA_real_, J)
  adjusted[exact] <- candidate[exact]
  list(adjusted = adjusted, rejected = decision$rejected,
       n_rejected = decision$n_rejected, exact = exact)
}

csm_incongruity <- function(z, scores,
                            target = c("pleiotropy", "replication", "mediation"),
                            t = 1L, max_n = 5000L, tolerance = 0, seed = NULL) {
  target <- match.arg(target)
  z <- as.matrix(z)
  if (nrow(z) != length(scores)) stop("'z' must have one row per score.", call. = FALSE)
  idx <- seq_len(nrow(z))
  if (length(idx) > max_n) {
    if (!is.null(seed)) set.seed(seed)
    idx <- sort(sample(idx, max_n))
  }
  zs <- z[idx, , drop = FALSE]
  sc <- scores[idx]
  rep <- .order_representation(zs, target, as.integer(t))
  comparable <- 0L
  violations <- 0L
  for (g in unique(rep$group)) {
    members <- which(rep$group == g)
    if (length(members) < 2L) next
    for (i in members) {
      others <- members[members != i]
      dominates <- rowSums(rep$w[others, , drop = FALSE] >=
                           matrix(rep$w[i, ], length(others), ncol(zs), byrow = TRUE)) == ncol(zs)
      dominates <- dominates & rowSums(rep$w[others, , drop = FALSE] !=
                                       matrix(rep$w[i, ], length(others), ncol(zs), byrow = TRUE)) > 0L
      comparable <- comparable + sum(dominates)
      violations <- violations + sum(sc[others[dominates]] > sc[i] + tolerance)
    }
  }
  list(n = length(idx), comparable_pairs = comparable, violations = violations,
       violation_rate = if (comparable) violations / comparable else NA_real_)
}
