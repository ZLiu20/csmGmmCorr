.scalar_number <- function(x, label, lower = -Inf, upper = Inf) {
  ok <- is.numeric(x) && length(x) == 1L && !is.na(x) &&
    x >= lower && x <= upper
  if (!ok) stop(sprintf("'%s' is outside its permitted range.", label), call. = FALSE)
  invisible(x)
}

.support_matrix <- function(K) {
  ids <- 0:(2^K - 1L)
  A <- vapply(ids, function(b) as.integer(intToBits(b))[seq_len(K)], integer(K))
  list(id = ids, A = t(A), size = colSums(A))
}

.sign_grid <- function(s) {
  if (s == 0L) return(matrix(0, 1L, 0L))
  as.matrix(expand.grid(rep(list(c(-1, 1)), s)))
}

.build_components <- function(A) {
  K <- ncol(A)
  pieces <- lapply(seq_len(nrow(A)), function(g) {
    active <- which(A[g, ] != 0L)
    sg <- .sign_grid(length(active))
    H <- matrix(0L, nrow(sg), K)
    if (length(active)) H[, active] <- sg
    data.frame(grp = g, size = length(active), H, check.names = FALSE)
  })
  d <- do.call(rbind, pieces)
  list(H = as.matrix(d[, -(1:2), drop = FALSE]), grp = d$grp, size = d$size)
}

.build_pairs <- function(A) {
  K <- ncol(A)
  out <- lapply(seq_len(nrow(A)), function(g) {
    active <- which(A[g, ] != 0L)
    if (!length(active)) {
      H <- matrix(0L, 1L, K)
      return(list(H = H, grp = g, size = 0L, self = TRUE))
    }
    sg <- .sign_grid(length(active))
    sg <- sg[sg[, ncol(sg)] == 1L, , drop = FALSE]
    H <- matrix(0L, nrow(sg), K)
    H[, active] <- sg
    list(H = H, grp = rep.int(g, nrow(H)), size = rep.int(length(active), nrow(H)),
         self = rep(FALSE, nrow(H)))
  })
  list(
    H = do.call(rbind, lapply(out, `[[`, "H")),
    grp = unlist(lapply(out, `[[`, "grp"), use.names = FALSE),
    size = unlist(lapply(out, `[[`, "size"), use.names = FALSE),
    self = unlist(lapply(out, `[[`, "self"), use.names = FALSE)
  )
}

.new_spec <- function(K, M, S, magnitudes, a_mu, b_mu, kappa) {
  supports <- .support_matrix(K)
  keep <- supports$size <= S
  ids <- supports$id[keep]
  support_A <- supports$A[keep, , drop = FALSE]
  support_size <- supports$size[keep]
  M_keep <- M[ids + 1L]
  grp_b <- rep(ids, M_keep)
  grp_m <- sequence(M_keep)
  grp_A <- support_A[match(grp_b, ids), , drop = FALSE]
  grp_size <- rowSums(grp_A)
  comp <- .build_components(grp_A)
  pair <- .build_pairs(grp_A)
  full <- which(grp_b == 2^K - 1L)
  other <- lapply(seq_len(K), function(k) which(grp_A[, k] == 1L & !(seq_along(grp_b) %in% full)))
  structure(list(
    K = K, M = M, S = S, magnitudes = magnitudes,
    a_mu = a_mu, b_mu = b_mu, kappa = kappa,
    support_b = ids, support_A = support_A, support_size = support_size,
    grp_b = grp_b, grp_m = grp_m, grp_A = grp_A, grp_size = grp_size,
    full = full, other = other, comp = comp, pair = pair
  ), class = "csm_spec")
}

csm_spec <- function(K, M = csm_structure(K, 2L, 1L), S = K,
                     a_mu = 0.5, b_mu = NULL, kappa = 0.05) {
  .scalar_number(K, "K", 2, 12)
  K <- as.integer(K)
  .scalar_number(S, "S", 1, K)
  S <- as.integer(S)
  .scalar_number(a_mu, "a_mu", 0)
  if (!is.null(b_mu)) .scalar_number(b_mu, "b_mu", a_mu)
  .scalar_number(kappa, "kappa", 0, 1)
  if (length(M) == 1L) M <- rep(as.integer(M), 2^K)
  if (length(M) != 2^K || any(!is.finite(M)) || any(M < 1) || any(M != round(M))) {
    stop("'M' must contain one positive integer or 2^K positive integers.", call. = FALSE)
  }
  M <- as.integer(M)
  M[1L] <- 1L
  .new_spec(K, M, S, "full", a_mu, if (is.null(b_mu)) Inf else b_mu, kappa)
}

print.csm_spec <- function(x, ...) {
  cat("Correlated csmGmm specification\n")
  cat(sprintf("  K = %d, largest support size = %d\n", x$K, x$S))
  cat(sprintf("  support-component groups = %d, signed configurations = %d\n",
              length(x$grp_b), nrow(x$comp$H)))
  invisible(x)
}

.project_correlation <- function(S, kappa) {
  S <- (S + t(S)) / 2
  d <- sqrt(pmax(diag(S), .Machine$double.eps))
  R <- S / outer(d, d)
  R[!is.finite(R)] <- 0
  diag(R) <- 1
  ev <- eigen(R, symmetric = TRUE)
  ev$values <- pmax(ev$values, kappa)
  R <- ev$vectors %*% (ev$values * t(ev$vectors))
  d <- sqrt(diag(R))
  R <- R / outer(d, d)
  R <- (R + t(R)) / 2
  diag(R) <- 1
  if (min(eigen(R, symmetric = TRUE, only.values = TRUE)$values) < kappa) {
    lo <- min(eigen(R, symmetric = TRUE, only.values = TRUE)$values)
    alpha <- min(1, max(0, (kappa - lo) / (1 - lo)))
    R <- (1 - alpha) * R + alpha * diag(nrow(R))
  }
  R
}

.project_mu <- function(mu, spec) {
  mu <- as.matrix(mu)
  mu[spec$grp_A == 0L] <- 0
  active <- spec$grp_A == 1L
  mu[active] <- pmin(spec$b_mu, pmax(spec$a_mu, mu[active]))
  if (length(spec$full)) {
    for (k in seq_len(spec$K)) {
      others <- spec$other[[k]]
      if (!length(others)) next
      floor_k <- max(mu[others, k])
      mu[spec$full, k] <- pmax(mu[spec$full, k], floor_k)
    }
  }
  mu
}

.ordering_ok <- function(mu, spec, tol = 1e-10) {
  if (!length(spec$full)) return(TRUE)
  for (k in seq_len(spec$K)) {
    o <- spec$other[[k]]
    if (length(o) && min(mu[spec$full, k]) + tol < max(mu[o, k])) return(FALSE)
  }
  TRUE
}

.parameter_issues <- function(p, spec) {
  problems <- character()
  G <- length(spec$grp_b)
  if (!is.numeric(p$varpi) || length(p$varpi) != G || any(!is.finite(p$varpi)) ||
      any(p$varpi < 0) || abs(sum(p$varpi) - 1) > 1e-8) problems <- c(problems, "varpi")
  if (!is.matrix(p$mu) || !identical(dim(p$mu), c(G, spec$K)) || any(!is.finite(p$mu))) {
    problems <- c(problems, "mu")
  } else {
    if (any(abs(p$mu[spec$grp_A == 0L]) > 1e-10) ||
        any(p$mu[spec$grp_A == 1L] < spec$a_mu - 1e-10) ||
        any(p$mu[spec$grp_A == 1L] > spec$b_mu + 1e-10) || !.ordering_ok(p$mu, spec)) {
      problems <- c(problems, "mu constraints")
    }
  }
  R <- p$Sigma
  if (!is.matrix(R) || !identical(dim(R), c(spec$K, spec$K)) || any(!is.finite(R)) ||
      max(abs(R - t(R))) > 1e-8 || max(abs(diag(R) - 1)) > 1e-8 ||
      min(eigen(R, symmetric = TRUE, only.values = TRUE)$values) < spec$kappa - 1e-8) {
    problems <- c(problems, "Sigma")
  }
  unique(problems)
}

.sun_pi_to_vector <- function(pi, spec) {
  if (!is.list(pi)) return(as.numeric(pi))
  if (length(pi) != 2^spec$K) stop("A 'pi' list must have 2^K elements.", call. = FALSE)
  unlist(pi[spec$support_b + 1L], use.names = FALSE)
}

.sun_mu_to_matrix <- function(mu, spec) {
  G <- length(spec$grp_b)
  K <- spec$K
  if (is.numeric(mu) && is.null(dim(mu)) && length(mu) == K) {
    return(.project_mu(matrix(rep(mu, each = G), G, K), spec))
  }
  if (is.matrix(mu) && identical(dim(mu), c(G, K))) return(mu)
  if (!is.list(mu) || length(mu) != 2^K) stop("'mu' has an unsupported shape.", call. = FALSE)
  out <- matrix(0, G, K)
  for (b in spec$support_b) {
    g <- which(spec$grp_b == b)
    z <- as.matrix(mu[[b + 1L]])
    if (nrow(z) == K && ncol(z) == length(g)) z <- t(z)
    if (!identical(dim(z), c(length(g), K))) stop("A mu-list element has the wrong dimensions.", call. = FALSE)
    out[g, ] <- z
  }
  out
}

csm_params <- function(spec, varpi = NULL, mu, Sigma = diag(spec$K), pi = NULL) {
  if (!inherits(spec, "csm_spec")) stop("'spec' must come from csm_spec().", call. = FALSE)
  if (is.null(varpi) == is.null(pi)) stop("Supply exactly one of 'varpi' and 'pi'.", call. = FALSE)
  w <- if (is.null(varpi)) .sun_pi_to_vector(pi, spec) else as.numeric(varpi)
  if (sum(w) <= 0) stop("Mixture weights must have positive total mass.", call. = FALSE)
  w <- w / sum(w)
  out <- list(varpi = w, mu = .sun_mu_to_matrix(mu, spec),
              Sigma = .project_correlation(as.matrix(Sigma), spec$kappa))
  bad <- .parameter_issues(out, spec)
  if (length(bad)) stop(paste("Infeasible parameters:", paste(bad, collapse = ", ")), call. = FALSE)
  structure(out, class = "csm_params")
}

as_sun_lists <- function(object, spec = NULL) {
  if (inherits(object, "csm_fit")) {
    spec <- object$spec
    object <- object$params
  }
  if (is.null(spec) || !inherits(spec, "csm_spec")) stop("A csm_spec object is required.", call. = FALSE)
  pi_list <- vector("list", 2^spec$K)
  mu_list <- vector("list", 2^spec$K)
  for (b in 0:(2^spec$K - 1L)) {
    g <- which(spec$grp_b == b)
    if (length(g)) {
      pi_list[[b + 1L]] <- object$varpi[g]
      mu_list[[b + 1L]] <- t(object$mu[g, , drop = FALSE])
    } else {
      pi_list[[b + 1L]] <- numeric()
      mu_list[[b + 1L]] <- matrix(numeric(), spec$K, 0L)
    }
  }
  list(muList = mu_list, piList = pi_list, Sigma = object$Sigma)
}

