csm_stepup <- function(lfdr, q = 0.1) {
  if (!is.numeric(lfdr) || any(!is.finite(lfdr)) || any(lfdr < 0 | lfdr > 1)) {
    stop("'lfdr' must contain finite values in [0, 1].", call. = FALSE)
  }
  .scalar_number(q, "q", 0, 1)
  J <- length(lfdr)
  ord <- order(lfdr, seq_len(J))
  averages <- cumsum(lfdr[ord]) / seq_len(J)
  admissible <- which(averages <= q)
  r <- if (length(admissible)) max(admissible) else 0L
  rejected <- rep(FALSE, J)
  if (r) rejected[ord[seq_len(r)]] <- TRUE
  list(rejected = rejected, n_rejected = r,
       cutoff = if (r) lfdr[ord[r]] else NA_real_,
       average = if (r) averages[r] else NA_real_)
}

csm_extrapolation <- function(fit, z, target = c("pleiotropy", "replication", "mediation"),
                              t = 1L, rejected, cutoff, pairs = NULL, margin = 3) {
  target <- match.arg(target)
  z <- .validate_z(z, fit$spec$K)
  if (!is.logical(rejected) || length(rejected) != nrow(z)) stop("'rejected' has the wrong length.", call. = FALSE)
  used <- fit$params$varpi > 0
  caps <- vapply(seq_len(fit$spec$K), function(k) {
    values <- fit$params$mu[used & fit$spec$grp_A[, k] == 1L, k]
    (if (length(values)) max(values) else fit$spec$a_mu) + margin
  }, numeric(1))
  flag <- rep(NA, nrow(z))
  winsor_lfdr <- rep(NA_real_, nrow(z))
  if (any(rejected)) {
    zr <- z[rejected, , drop = FALSE]
    zw <- sign(zr) * pmin(abs(zr), matrix(caps, nrow(zr), fit$spec$K, byrow = TRUE))
    winsor_lfdr[rejected] <- csm_lfdr(fit, zw, target, t, pairs)
    flag[rejected] <- winsor_lfdr[rejected] > cutoff
  }
  list(flag = flag, lfdr_winsorized = winsor_lfdr, caps = caps)
}

csm_test <- function(fit, z, target = c("pleiotropy", "replication", "mediation"),
                     t = 1L, q = 0.1, pairs = NULL, adjust = FALSE,
                     extrapolation = TRUE, allow_unconverged = FALSE) {
  target <- match.arg(target)
  if (!inherits(fit, "csm_fit")) stop("'fit' must come from csm_fit().", call. = FALSE)
  z <- .validate_z(z, fit$spec$K)
  out <- list(target = target, t = t, q = q, J = nrow(z))
  if ((!fit$converged && !allow_unconverged) || is.null(fit$params)) {
    out$status <- "failed"
    out$lfdr <- rep(NA_real_, nrow(z))
    out$rejected <- rep(FALSE, nrow(z))
    out$n_rejected <- 0L
    return(structure(out, class = "csm_test"))
  }
  out$status <- if (fit$converged) "ok" else "unconverged"
  out$lfdr <- csm_lfdr(fit, z, target, t, pairs, cores = fit$control$cores)
  decision <- csm_stepup(out$lfdr, q)
  out$rejected <- decision$rejected
  out$n_rejected <- decision$n_rejected
  out$cutoff <- decision$cutoff
  if (extrapolation) {
    ex <- csm_extrapolation(fit, z, target, t, out$rejected, out$cutoff, pairs)
    out$extrapolation <- ex$flag
    out$lfdr_winsorized <- ex$lfdr_winsorized
  }
  if (adjust) out$adjusted <- csm_adjust(z, out$lfdr, target, t, q)
  structure(out, class = "csm_test")
}

predict.csm_fit <- function(object, newdata,
                            target = c("pleiotropy", "replication", "mediation"),
                            t = 1L, pairs = NULL, ...) {
  csm_lfdr(object, newdata, match.arg(target), t, pairs)
}

print.csm_test <- function(x, ...) {
  cat(sprintf("Correlated csmGmm test: %s, t = %d, q = %g, %d features\n",
              x$target, as.integer(x$t), x$q, x$J))
  if (x$status == "failed") {
    cat("  fit failed: no discoveries\n")
    return(invisible(x))
  }
  if (x$status == "unconverged") cat("  warning: inference uses an unconverged fit\n")
  cat(sprintf("  discoveries: %d\n", x$n_rejected))
  if (!is.null(x$extrapolation) && x$n_rejected) {
    cat(sprintf("  extrapolation-sensitive discoveries: %d\n", sum(x$extrapolation, na.rm = TRUE)))
  }
  if (!is.null(x$adjusted)) cat(sprintf("  discoveries after monotone adjustment: %d\n", x$adjusted$n_rejected))
  invisible(x)
}

csm_simulate <- function(n, params, spec) {
  if (!inherits(spec, "csm_spec")) stop("'spec' must come from csm_spec().", call. = FALSE)
  .scalar_number(n, "n", 1)
  comp <- spec$comp
  w <- params$varpi[comp$grp] / 2^comp$size
  state <- sample.int(length(w), as.integer(n), replace = TRUE, prob = w)
  mean <- comp$H[state, , drop = FALSE] * params$mu[comp$grp[state], , drop = FALSE]
  z <- mean + matrix(stats::rnorm(as.integer(n) * spec$K), as.integer(n), spec$K) %*% chol(params$Sigma)
  list(z = z, H = comp$H[state, , drop = FALSE], groups = comp$grp[state])
}

