library(csmGmmCorr)

assert <- function(ok, label) {
  if (!isTRUE(ok)) stop(paste("FAILED:", label), call. = FALSE)
  cat("ok -", label, "\n")
}

set.seed(101)
spec <- csm_spec(3, M = 1, b_mu = 8)
weights <- ifelse(spec$grp_b == 0L, 0.75, 0.25 / (length(spec$grp_b) - 1L))
truth <- csm_params(spec, varpi = weights, mu = c(2, 2.5, 3),
                    Sigma = matrix(c(1, .2, .1, .2, 1, .25, .1, .25, 1), 3))
assert(inherits(spec, "csm_spec"), "specification class")
assert(length(truth$varpi) == length(spec$grp_b), "parameter dimensions")

sim <- csm_simulate(500, truth, spec)
assert(identical(dim(sim$z), c(500L, 3L)), "simulation dimensions")

small <- sim$z[1:12, , drop = FALSE]
lfdr <- csm_lfdr(truth, small, "pleiotropy", 1, spec = spec)
H <- spec$comp$H
means <- H * truth$mu[spec$comp$grp, , drop = FALSE]
precision <- solve(truth$Sigma)
normalizer <- sqrt((2 * pi)^3 * det(truth$Sigma))
brute <- vapply(seq_len(nrow(small)), function(i) {
  density <- vapply(seq_len(nrow(H)), function(r) {
    delta <- small[i, ] - means[r, ]
    truth$varpi[spec$comp$grp[r]] / 2^spec$comp$size[r] *
      exp(-0.5 * sum(delta * (precision %*% delta))) / normalizer
  }, numeric(1))
  sum(density[rowSums(H != 0) <= 1L]) / sum(density)
}, numeric(1))
assert(max(abs(lfdr - brute)) < 1e-10, "lfdr agrees with direct posterior")

for (target in c("pleiotropy", "replication", "mediation")) {
  K <- if (target == "mediation") 4L else 3L
  z <- matrix(rnorm(160 * K), 160, K)
  score <- runif(160)
  adjusted <- csm_adjust(z, score, target, 1, q = 0.1, all = TRUE)
  diagnostic <- csm_incongruity(z, adjusted$adjusted, target, 1, max_n = 160)
  assert(diagnostic$violations == 0L, paste("majorant order", target))
}

rule <- csm_stepup(c(.01, .04, .2, .5), .1)
assert(rule$n_rejected == 3L && identical(which(rule$rejected), 1:3), "step-up rule")

round_trip <- as_sun_lists(truth, spec)
truth2 <- csm_params(spec, pi = round_trip$piList, mu = round_trip$muList,
                     Sigma = round_trip$Sigma)
assert(max(abs(truth$varpi - truth2$varpi)) < 1e-12 &&
       max(abs(truth$mu - truth2$mu)) < 1e-12, "support-list round trip")

fit_spec <- csm_spec(2, M = 1, b_mu = 7)
fit_truth <- csm_params(fit_spec, varpi = c(.75, .08, .08, .09),
                        mu = c(2.5, 2.5), Sigma = matrix(c(1, .2, .2, 1), 2))
train <- csm_simulate(1200, fit_truth, fit_spec)$z
fit <- csm_fit(train, fit_spec, starts = c("null", "equal"),
               control = csm_control(max_iter = 300, tol_loglik = 1e-7,
                                     penalty = 0, weight_penalty = 0))
assert(!is.null(fit$params) && all(diff(fit$traces[[fit$selected]]) >= -1e-8),
       "fit returns a monotone feasible run")
assert(!length(csmGmmCorr:::.parameter_issues(fit$params, fit$spec)), "fitted parameters are feasible")

failed <- csm_fit(train, fit_spec, starts = "null",
                  control = csm_control(max_iter = 1, tol_loglik = 0,
                                        penalty = 0, weight_penalty = 0))
failed_test <- csm_test(failed, train[1:20, , drop = FALSE], "pleiotropy", 1)
assert(!failed$converged && failed_test$n_rejected == 0L, "failed fit makes no discoveries")

cat("All package tests passed.\n")
